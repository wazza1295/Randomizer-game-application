//
//  HW3_APPApp.swift
//  HW3 APP
//
//  Created by Waseem on 6/3/23.
//

import SwiftUI

@main
struct HW3_APPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
